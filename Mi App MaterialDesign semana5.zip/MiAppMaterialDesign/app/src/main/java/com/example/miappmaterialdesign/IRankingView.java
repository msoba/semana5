package com.example.miappmaterialdesign;

import com.example.miappmaterialdesign.Mascota;
import com.example.miappmaterialdesign.Mascota_ranking_adapter;

import java.util.ArrayList;

public interface IRankingView {

    public void LinearLayoutVertical();
    public Mascota_ranking_adapter creaAdaptador(ArrayList<Mascota> mascotas);
    public void inicializaAdaptador(Mascota_ranking_adapter adaptador);
}
