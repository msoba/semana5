package com.example.miappmaterialdesign;

public interface IPresenter {

    public void ExtraerMascotasbd();

    public void VerMascotas();
}
