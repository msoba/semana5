package com.example.miappmaterialdesign;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class cardview_img_mascota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardview_img_mascota);
    }
}