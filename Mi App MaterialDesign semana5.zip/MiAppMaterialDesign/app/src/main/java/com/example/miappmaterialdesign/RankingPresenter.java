package com.example.miappmaterialdesign;

import android.content.Context;

import java.util.ArrayList;

import bd.Constructor_ranking;

public class RankingPresenter implements IPresenter {

    private IRankingView RankingView;
    private Context context;
    private Constructor_ranking constructorRanking;
    private ArrayList<Mascota> mascotas;

    public RankingPresenter(IRankingView RankingView, Context context) {
        this.RankingView = RankingView;
        this.context = context;
        ExtraerMascotasbd();
    }

    @Override
    public void ExtraerMascotasbd() {
        constructorRanking = new Constructor_ranking(context);
        mascotas = constructorRanking.ExtraerDatos();
        VerMascotas();
    }

    @Override
    public void VerMascotas() {
        RankingView.inicializaAdaptador(RankingView.creaAdaptador(mascotas));
        RankingView.LinearLayoutVertical();
    }
}
