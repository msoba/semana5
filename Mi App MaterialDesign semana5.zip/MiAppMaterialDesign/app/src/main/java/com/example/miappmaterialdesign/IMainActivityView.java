package com.example.miappmaterialdesign;

import com.example.miappmaterialdesign.Mascota;
import com.example.miappmaterialdesign.Mascota_adapter;

import java.util.ArrayList;

public interface IMainActivityView {

    public void LinearLayoutVertical();
    public Mascota_adapter creaAdaptador(ArrayList<Mascota> mascotas);
    public void inicializaAdaptador(Mascota_adapter adaptador);

}
