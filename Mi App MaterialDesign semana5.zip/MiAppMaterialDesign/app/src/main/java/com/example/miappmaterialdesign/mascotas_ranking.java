package com.example.miappmaterialdesign;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import androidx.appcompat.widget.Toolbar;

import java.util.ArrayList;

public class mascotas_ranking extends AppCompatActivity implements IRankingView {


    private RecyclerView listaMascotas;
    public Mascota_ranking_adapter adapter;
    ArrayList<Mascota> mascotas;
    private IPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascotas_ranking);
        Toolbar ActBar = (Toolbar) findViewById(R.id.ActBar);
        setSupportActionBar(ActBar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listaMascotas = (RecyclerView) findViewById(R.id.rvMascotasRank);

        presenter = new RankingPresenter(this, this);

        inicializaListaMascotas();


    }

    public void inicializaListaMascotas() {
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota(R.drawable.perro1, "Toby",50));
        mascotas.add(new Mascota(R.drawable.perro2, "Uma",2));
        mascotas.add(new Mascota(R.drawable.perro3, "Bako",38));
        mascotas.add(new Mascota(R.drawable.perro4, "Hugo", 5));
        mascotas.add(new Mascota(R.drawable.perro5, "Tango",22));
    }

    @Override
    public void LinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);

    }

    @Override
    public Mascota_ranking_adapter creaAdaptador(ArrayList<Mascota> mascotas) {
        Mascota_ranking_adapter adaptador = new Mascota_ranking_adapter(mascotas, this);
        return adaptador;
    }

    @Override
    public void inicializaAdaptador(Mascota_ranking_adapter adaptador) {
        listaMascotas.setAdapter(adaptador);
    }
}