package com.example.miappmaterialdesign;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements IMainActivityView {

    private ArrayList<Mascota> mascotas;
    private RecyclerView rvMascotas;
    private IPresenter presenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar ActBar = (Toolbar) findViewById(R.id.ActBar);
        setSupportActionBar(ActBar);

        rvMascotas = (RecyclerView) findViewById(R.id.rvMascotas);

        presenter = new MainActivityPresenter(this, this);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_opciones, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        Intent i = new Intent(this, mascotas_ranking.class);
        startActivity(i);
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void LinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rvMascotas.setLayoutManager(llm);
    }

    @Override
    public Mascota_adapter creaAdaptador(ArrayList<Mascota> mascotas) {
        Mascota_adapter adaptador = new Mascota_adapter(mascotas, this);
        return adaptador;
    }

    @Override
    public void inicializaAdaptador(Mascota_adapter adaptador) {
        rvMascotas.setAdapter(adaptador);
    }
}