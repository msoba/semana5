package com.example.miappmaterialdesign;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;

public class programador extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programador);
        Toolbar ActBar = (Toolbar) findViewById(R.id.ActBar);
        setSupportActionBar(ActBar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
}