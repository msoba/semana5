package com.example.miappmaterialdesign;

import android.content.Context;

import java.util.ArrayList;

import bd.Constructor_mascota;

public class MainActivityPresenter implements IPresenter {

    private IMainActivityView iMainActivityView;
    private Context context;
    private Constructor_mascota constructorMascotas;
    private ArrayList<Mascota> mascotas;

    public MainActivityPresenter(IMainActivityView iMainActivityView, Context context) {
        this.iMainActivityView = iMainActivityView;
        this.context = context;
        ExtraerMascotasbd();
    }


    @Override
    public void ExtraerMascotasbd() {
        constructorMascotas = new Constructor_mascota(context);
        mascotas = constructorMascotas.ExtraerDatos();
        VerMascotas();
    }

    @Override
    public void VerMascotas() {
        iMainActivityView.inicializaAdaptador(iMainActivityView.creaAdaptador(mascotas));
        iMainActivityView.LinearLayoutVertical();
    }
}
