package com.example.miappmaterialdesign;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class card_mascota extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_mascota);
    }
}