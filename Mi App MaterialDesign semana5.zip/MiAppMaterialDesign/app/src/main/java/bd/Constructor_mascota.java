package bd;

import android.content.ContentValues;
import android.content.Context;

import com.example.miappmaterialdesign.Mascota;
import com.example.miappmaterialdesign.R;

import java.util.ArrayList;

import static bd.Constante_bd.*;

public class Constructor_mascota {

    private static final Integer LIKE = 1;
    private Context context;

    public Constructor_mascota(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> ExtraerDatos() {
        Base_datos db = new Base_datos(context);

        ArrayList<Mascota> control = db.listarMascotas();
        if (control.size()<10) {
            insertarMascotas(db);
        }
        return db.listarMascotas();
    }


    public void insertarMascotas(Base_datos db){

        ContentValues contentValues;
        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Bonito");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN, R.drawable.perro1);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Duqui");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro2);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Pulgui");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro3);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Toby");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro4);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Hugo");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro5);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Tango");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro6);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Chiquito");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro7);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Lisa");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro1);
        db.insertarMascota(contentValues);
        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Bako");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.mascota_correa);
        db.insertarMascota(contentValues);

        contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_MASCOTAS_NOMBRE, "Piru");
        contentValues.put(Constante_bd.TABLE_MASCOTAS_IMAGEN,R.drawable.perro2);
        db.insertarMascota(contentValues);

    }

    public void darLikeMascota(Mascota mascota) {
        Base_datos db = new Base_datos(context);
        ContentValues contentValues = new ContentValues();
        contentValues.put(Constante_bd.TABLE_LIKES_MASCOTA_ID_MASCOTA, mascota.getId_mascota());
        contentValues.put(Constante_bd.TABLE_LIKES_MASCOTA_CANTIDAD_LIKES, LIKE);
        db.insertarLikeMascota(contentValues);
    }

    public int LikesMascota(Mascota mascota){
        Base_datos db = new Base_datos(context);
        return db.LikesMascota(mascota);
    }
}
