package bd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.miappmaterialdesign.Mascota;

import java.util.ArrayList;

public class Base_datos extends SQLiteOpenHelper {

    private Context context;

    public Base_datos(@Nullable Context context) {
        super(context, Constante_bd.DATABASE_NAME, null, Constante_bd.DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String queryCrearTablaMascota = "CREATE TABLE " + Constante_bd.TABLE_MASCOTAS + "(" +
                Constante_bd.TABLE_MASCOTAS_ID                   + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Constante_bd.TABLE_MASCOTAS_NOMBRE               + " TEXT, " +
                Constante_bd.TABLE_MASCOTAS_IMAGEN                 + " INTEGER" +
                ")";

        String queryCrearTablaMascotaLikes = "CREATE TABLE " + Constante_bd.TABLE_LIKES_MASCOTA + "(" +
                Constante_bd.TABLE_LIKES_MASCOTA_ID              + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Constante_bd.TABLE_LIKES_MASCOTA_ID_MASCOTA      + " INTEGER, " +
                Constante_bd.TABLE_LIKES_MASCOTA_CANTIDAD_LIKES    + " INTEGER, " +
                "FOREIGN KEY (" + Constante_bd.TABLE_LIKES_MASCOTA_ID_MASCOTA + ")" +
                "REFERENCES " + Constante_bd.TABLE_MASCOTAS + "(" + Constante_bd.TABLE_MASCOTAS_ID + ")" +
                ")";

        db.execSQL(queryCrearTablaMascota);
        db.execSQL(queryCrearTablaMascotaLikes);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Constante_bd.TABLE_MASCOTAS);
        db.execSQL("DROP TABLE IF EXISTS " + Constante_bd.TABLE_LIKES_MASCOTA);
        onCreate(db);
    }


    public ArrayList<Mascota> listarMascotas() {

        ArrayList<Mascota> mascotas = new ArrayList<>();

        String query = "SELECT " +
                Constante_bd.TABLE_MASCOTAS_ID + ", " +
                Constante_bd.TABLE_MASCOTAS_NOMBRE + ", " +
                Constante_bd.TABLE_MASCOTAS_IMAGEN + "," +
                " (SELECT COUNT(" + Constante_bd.TABLE_LIKES_MASCOTA_CANTIDAD_LIKES + ")" +
                " FROM " + Constante_bd.TABLE_LIKES_MASCOTA +
                " WHERE " + Constante_bd.TABLE_LIKES_MASCOTA + "." +
                Constante_bd.TABLE_LIKES_MASCOTA_ID_MASCOTA + "=" +
                Constante_bd.TABLE_MASCOTAS + "." +
                Constante_bd.TABLE_MASCOTAS_ID + ") contador_likes" +
                " FROM " + Constante_bd.TABLE_MASCOTAS;

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()) {
            Mascota mascota1 = new Mascota();
            mascota1.setId_mascota(registros.getInt(0));
            mascota1.setNombre(registros.getString(1));
            mascota1.setPuntaje(registros.getInt(2));
            mascota1.setPuntaje(registros.getInt(3));
            mascotas.add(mascota1);
        }

        db.close();
        return mascotas;

    }

    public ArrayList<Mascota> TopCincoMascotas() {

        ArrayList<Mascota> mascotas = new ArrayList<>();

        String query = "SELECT " +
                Constante_bd.TABLE_MASCOTAS_ID + ", " +
                Constante_bd.TABLE_MASCOTAS_NOMBRE + ", " +
                Constante_bd.TABLE_MASCOTAS_IMAGEN + "," +
                " (SELECT COUNT(" + Constante_bd.TABLE_LIKES_MASCOTA_CANTIDAD_LIKES + ")" +
                " FROM " + Constante_bd.TABLE_LIKES_MASCOTA +
                " WHERE " + Constante_bd.TABLE_LIKES_MASCOTA + "." +
                Constante_bd.TABLE_LIKES_MASCOTA_ID_MASCOTA + "=" +
                Constante_bd.TABLE_MASCOTAS + "." +
                Constante_bd.TABLE_MASCOTAS_ID + ") contador_likes" +
                " FROM " + Constante_bd.TABLE_MASCOTAS +
                " ORDER BY " + "contador_likes" + " DESC" +
                " LIMIT 5";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor registros = db.rawQuery(query, null);

        while (registros.moveToNext()) {
            Mascota mascota1 = new Mascota();
            mascota1.setId_mascota(registros.getInt(0));
            mascota1.setNombre(registros.getString(1));
            mascota1.setPuntaje(registros.getInt(2));
            mascota1.setPuntaje(registros.getInt(3));
            mascotas.add(mascota1);
        }

        db.close();
        return mascotas;

    }


    public void insertarMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(Constante_bd.TABLE_MASCOTAS, null, contentValues);
        db.close();
    }

    public void insertarLikeMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(Constante_bd.TABLE_LIKES_MASCOTA, null, contentValues);
        db.close();
    }

    public int LikesMascota(Mascota mascota){

        int likes = 0;

        String query = "SELECT COUNT(" + Constante_bd.TABLE_LIKES_MASCOTA_CANTIDAD_LIKES + ")" +
                " FROM " + Constante_bd.TABLE_LIKES_MASCOTA +
                " WHERE " + Constante_bd.TABLE_LIKES_MASCOTA_ID_MASCOTA + "=" +
                mascota.getId_mascota();

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(query, null);

        if (registros.moveToNext()) {
            likes = registros.getInt(0);
        }

        db.close();

        return likes;
    }

}
