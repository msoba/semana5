package bd;

import android.content.Context;

import com.example.miappmaterialdesign.Mascota;

import java.util.ArrayList;

public class Constructor_ranking {

    private Context context;

    public Constructor_ranking(Context context) {
        this.context = context;
    }

    public ArrayList<Mascota> ExtraerDatos() {

        Base_datos db = new Base_datos(context);
        return db.TopCincoMascotas();

    }

}
